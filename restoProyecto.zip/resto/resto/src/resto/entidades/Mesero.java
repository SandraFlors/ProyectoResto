package resto.entidades;

public class Mesero {

    //ATRIBUTOS-----------------------------------------------------------------
    private int idMesero;
    private String nombre;
    private int dni;
    private String usuario;
    private String contraseña;
    private boolean estado;
    
    //CONSTRUCTORES-------------------------------------------------------------

    public Mesero() {
    }

    public Mesero(int idMesero, String nombre, int dni, String usuario, String contraseña , boolean estado) {
        this.idMesero = idMesero;
        this.nombre = nombre;
        this.dni = dni;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.estado=estado;
    }

    public Mesero(String nombre, int dni, String usuario, String contraseña, boolean estado) {
        this.nombre = nombre;
        this.dni = dni;
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.estado=estado;
    }
    //GETTERS Y SETTERS---------------------------------------------------------

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getIdMesero() {
        return idMesero;
    }

    public void setIdMesero(int idMesero) {
        this.idMesero = idMesero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    //TO STRING-----------------------------------------------------------------

    @Override
    public String toString() {
        return "Mesero{" + "idMesero=" + idMesero + ", nombre=" + nombre + ", dni=" + dni + ", usuario=" + usuario + ", contrase\u00f1a=" + contraseña + ", estado=" + estado + '}';
    }

   

}
