package resto.entidades;

import java.time.LocalDate;
import java.time.LocalTime;

public class Reserva {
    //ATRIBUTOS-------------------------------------------------------------------

    private int idReserva;
    private String nombre;
    private double dni;
    private LocalDate fecha;
    private LocalTime hora;
    private boolean estado;

    //CONSTRUCTORES---------------------------------------------------------------
    public Reserva() {
    }

    public Reserva(int idReserva, String nombre, double dni, LocalDate fecha, LocalTime hora, boolean estado) {
        this.idReserva = idReserva;
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public Reserva(String nombre, double dni, LocalDate fecha, LocalTime hora, boolean estado) {
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }
    //GETTERS Y SETTERS---------------------------------------------------------

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getDni() {
        return dni;
    }

    public void setDni(double dni) {
        this.dni = dni;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    //TO STRING-----------------------------------------------------------------

    @Override
    public String toString() {
        return "Reserva{" + "idReserva=" + idReserva + ", nombre=" + nombre + ", dni=" + dni + ", fecha=" + fecha + ", hora=" + hora + ", estado=" + estado + '}';
    }

}
