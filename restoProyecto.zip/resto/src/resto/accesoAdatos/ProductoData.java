package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Producto;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoData {

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public ProductoData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }

//Métodos------------------------------------------------------------------------------------------------------------------------------
    public void agregarProducto(Producto producto) { //este metodo tendrá la tarea de hacer in INSERT en la tabla producto
        String sql = "INSERT INTO producto(codigo, nombre, cantidad, precio, estado)" + " VALUES (?,?,?,?,?)"; //datos a cargar (caracter comodin) luego remplazamos los signos por los datos correspondientes
        try {
            //generamos el objeto PreparedStatement----
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setInt(1, producto.getCodigo()); //SET=método de preparedStatement (1 UN metodo set x cada tipo de dato)
            pre.setString(2, producto.getNombre());
            pre.setInt(3, producto.getCantidad());
            pre.setDouble(4, producto.getPrecio());
            pre.setBoolean(5, producto.isEstado());
            pre.executeUpdate();

            //ahora devolvera lista con claves generadas a mesa 
            ResultSet res = pre.getGeneratedKeys(); //guardamos elr esultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado 
            if (res.next()) {//recorremos el resulset con un if
                producto.setIdProducto(res.getInt(1));
                JOptionPane.showMessageDialog(null, "Producto Agregado");
            }
            pre.close();//cerramos el preparedstatement
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Eror al acceder a la TABLA PRODUCTO" + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public void borrarProducto(Producto producto) {
        String sql = "UPDATE producto SET estado=0 WHERE idProducto=?";
        try {
            PreparedStatement pre = con.prepareStatement(sql);

            pre.setBoolean(1, producto.isEstado());

            int res = pre.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Producto Borrado");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la TABLA para Borrar producto");
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public void modificarProducto(Producto producto) {

        String sql = "UPDATE producto SET cantidad=?, precio=? WHERE IdProducto=?";
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, producto.getCantidad());
            pre.setDouble(2, producto.getPrecio());
            pre.setInt(3, producto.getIdProducto());
            int exe = pre.executeUpdate();
            if (exe == 1) {
                JOptionPane.showMessageDialog(null, "Producto Modificado!");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para modificar Producto");
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------   

    public Producto buscarProducto(int id) {
        String sql = "SELECT codigo, nombre , cantidad, precio FROM producto WHERE idProducto=? AND estado=1";
        Producto pro = null;
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re = pre.executeQuery();
            if (re.next()) {
                pro = new Producto();
                pro.setIdProducto(id);
                pro.setCodigo(re.getInt("codigo"));
                pro.setNombre(re.getString("nombre"));
                pro.setCantidad(re.getInt("cantidad"));
                pro.setPrecio(re.getDouble("precio"));
                pro.setEstado(true);

            } else {

                JOptionPane.showMessageDialog(null, "No existe el Producto");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesa para buscar mesa" + ex.getMessage());
        }
        return pro;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------- 

    public List<Producto> listarProducto() {
        String sql = "SELECT idProducto , codigo, nombre, cantidad, precio FROM producto WHERE estado=1";
        ArrayList<Producto> productos = new ArrayList<>();
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet re = pre.executeQuery();

            while (re.next()) {//mientras haiga elementos 
                Producto producto = new Producto();//creamos un producto
                producto.setIdProducto(re.getInt("idProducto"));
                producto.setCodigo(re.getInt("codigo"));
                producto.setNombre(re.getString("nombre"));
                producto.setCantidad(re.getInt("cantidad"));
                producto.setPrecio(re.getDouble("precio"));
                producto.setEstado(true);

                productos.add(producto);
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla PRODUCTO" + ex.getMessage());
        }
        return productos;
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------- 

}
