package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Reserva;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;

public class ReservaData {

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public ReservaData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
//Métodos------------------------------------------------------------------------------------------------------------------------------

    public Boolean agregarReserva(Reserva reserva, int idMesa) {//este metodo tendrá la tarea de hacer in INSERT en la tabla reserva
        String sql = "INSERT INTO reserva(nombre, dni, fecha, hora , estado,idMesa)" + " VALUES (?,?,?,?,?,?)";
        try {
            //generamos el objeto PreparedStatement----
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setString(1, reserva.getNombre());
            pre.setDouble(2, reserva.getDni());
            pre.setDate(3, Date.valueOf(reserva.getFecha()));//LocalDate fecha;se debe tranformar a date, se invoca el metodo value of y le pasamos x parametro reserva.get fecha
            pre.setTime(4, Time.valueOf(reserva.getHora()));//LocalTime hora;
            pre.setBoolean(5, reserva.isEstado());
            pre.setInt(6, idMesa);
            pre.executeUpdate();

            //ahora devolvera lista con claves generadas a mesa 
            ResultSet res = pre.getGeneratedKeys(); //guardamos elr esultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado 
            if (res.next()) {//recorremos el resulset con un if
                reserva.setIdReserva(1);
                JOptionPane.showMessageDialog(null, "Reserva Agregada");
            }
            pre.close();//cerramos el preparedstatement

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la TABLA RESERVA" + ex.getMessage());
        }
        return null;

    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public void eliminarReserva(Reserva reserva) {
        String sql = "DELETE FROM reserva WHERE idReserva=?";

        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, reserva.getIdReserva()); // Aquí pasamos el id de la reserva a eliminar
            int exe = pre.executeUpdate(); // Si la actualización es exitosa, se devuelve un número mayor que 0

            if (exe == 1) {
                JOptionPane.showMessageDialog(null, "Reserva Eliminada");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo eliminar la reserva", "Error", JOptionPane.ERROR_MESSAGE);
            }
            pre.close(); // Cerrar la declaración preparada
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla RESERVA para eliminar: " + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public void modificarReserva(Reserva reserva) {
        // Modificar la reserva incluyendo nombre, fecha, hora, etc.
        String sql = "UPDATE reserva SET nombre = ?, fecha = ?, hora = ? WHERE idReserva = ?";
        try {
            // Preparar la declaración SQL
            PreparedStatement pre = con.prepareStatement(sql);

            // Establecer los parámetros de la declaración
            pre.setString(1, reserva.getNombre()); // Establecer el nombre
            pre.setDate(2, java.sql.Date.valueOf(reserva.getFecha())); // Establecer la fecha (debe ser un java.sql.Date)
            pre.setTime(3, java.sql.Time.valueOf(reserva.getHora())); // Establecer la hora (debe ser un java.sql.Time)
            pre.setInt(4, reserva.getIdReserva()); // Establecer el ID de la reserva

            // Ejecutar la actualización en la base de datos
            int exe = pre.executeUpdate(); // Si la actualización es exitosa, se devuelve un número mayor a 0

            if (exe == 1) {
                JOptionPane.showMessageDialog(null, "Reserva Modificada!");
            }
            pre.close(); // Cerrar la declaración preparada
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al modificar la reserva: " + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------  

    public Reserva buscarReserva(long dni) { // Cambiar 'int' por 'long'
    String sql = "SELECT nombre, dni , fecha, hora FROM reserva WHERE dni=? AND estado=1"; // Cambiar 'idReserva' por 'dni'
    Reserva reserva = null;
    try {
        PreparedStatement pre = con.prepareStatement(sql);
        pre.setLong(1, dni); // Aquí ahora pasamos 'dni' como 'long'
        ResultSet re = pre.executeQuery();
        if (re.next()) {
            reserva = new Reserva();
            reserva.setDni(dni);  // Aquí ya usamos el 'dni' de tipo 'long'
            reserva.setNombre(re.getString("nombre"));
            reserva.setDni(re.getLong("dni")); // Obtener 'dni' como 'long'
            reserva.setFecha(re.getDate("fecha").toLocalDate());
            reserva.setHora(re.getTime("hora").toLocalTime());
            reserva.setEstado(true);
        } else {
            JOptionPane.showMessageDialog(null, "No existe la reserva con este DNI");
        }
        pre.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al acceder a la tabla de reservas: " + ex.getMessage());
    }
    return reserva;
}
//---------------------------------------------------------------------------------------------------------------------------------------------- 

    public Reserva buscarReservaPorDni(long dni) {
    String sql = "SELECT idReserva, idMesa, nombre, dni, fecha, hora FROM reserva WHERE dni=? AND estado=1";
    Reserva reserva = null;
    try {
        // Cambiar setInt por setLong, ya que 'dni' es un 'long'
        PreparedStatement pre = con.prepareStatement(sql);
        pre.setLong(1, dni); // Usar setLong en lugar de setInt
        ResultSet re = pre.executeQuery();
        if (re.next()) {
            reserva = new Reserva();
            reserva.setIdReserva(re.getInt("idReserva"));
            reserva.setNombre(re.getString("nombre"));
            // Cambiar getInt por getLong, ya que 'dni' es un 'long'
            reserva.setDni(re.getLong("dni")); // Usar getLong en lugar de getInt
            reserva.setFecha(re.getDate("fecha").toLocalDate());
            reserva.setHora(re.getTime("hora").toLocalTime());
            reserva.setEstado(true);
        } else {
            JOptionPane.showMessageDialog(null, "No Existe la Reserva");
        }
        pre.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al acceder: " + ex.getMessage());
    }
    return reserva;
}
    //---------------------------------------------------------------------------------------------------------------------------------------------- 

    public ArrayList<Reserva> listarTodasReservas() {
        ArrayList<Reserva> reservas = new ArrayList<>(); // Lista para almacenar las reservas
        String sql = "SELECT idReserva, nombre, dni, fecha, hora, estado, idMesa FROM reserva WHERE estado=1"; // Consulta para obtener todas las reservas activas

        try {
            PreparedStatement pre = con.prepareStatement(sql); // Preparamos la consulta
            ResultSet re = pre.executeQuery(); // Ejecutamos la consulta y obtenemos el resultado

            while (re.next()) { // Recorremos todos los resultados obtenidos
                Reserva reserva = new Reserva();
                reserva.setIdReserva(re.getInt("idReserva"));
                reserva.setNombre(re.getString("nombre"));
                reserva.setDni(re.getLong("dni"));
                reserva.setFecha(re.getDate("fecha").toLocalDate());
                reserva.setHora(re.getTime("hora").toLocalTime());
                reserva.setEstado(true); // Asumimos que el estado es 1 para las reservas activas
                reserva.setIdMesa(re.getInt("idMesa"));

                reservas.add(reserva); // Agregamos la reserva a la lista
            }
            pre.close(); // Cerramos el PreparedStatement

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla RESERVA: " + ex.getMessage());
        }

        return reservas; // Devolvemos la lista de reservas
    }
}
