package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Mesero;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MeseroData { 

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public MeseroData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }
//Métodos------------------------------------------------------------------------------------------------------------------------------

    public void AgregarMesero(Mesero mesero) {//este metodo tendrá la tarea de hacer in INSERT en la tabla Mesero
        String sql = "INSERT INTO mesero(nombre,dni,usuario,contraseña,estado)" + " VALUES (?,?,?,?,?)";//datos a cargar (caracter comodin) luego remplazamos los signos por los datos correspondientes
        try {
            //generamos el objeto PreparedStatement----
            PreparedStatement pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setString(1, mesero.getNombre());//SET=método de preparedStatement (1 UN metodo set x cada tipo de dato)
            pre.setInt(2, mesero.getDni());
            pre.setString(3, mesero.getUsuario());
            pre.setString(4, mesero.getContraseña());
            pre.setBoolean(5, mesero.isEstado());
            pre.executeUpdate();

            //ahora devolvera lista con claves generadas a mesero
            ResultSet re = pre.getGeneratedKeys(); //guardamos el resultado de la variable pre en un RESULTSET
            //RESULSET=matriz/tabla con una sola columna que seria el id y filas tantas como mesas haya insertado (en nuestro caso solo 1 )
            if (re.next()) {//recorremos el resulset con un if
                mesero.setIdMesero(re.getInt(1));
                JOptionPane.showMessageDialog(null, "Mesero Agregado");
            }
            pre.close();//cerramos el preparedstatement

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la TABLA MESERO" + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public void borrarMesero(Mesero mesero) {//este metodo se encargará de eliminar una mesa (DELETE)
        String sql = "UPDATE mesero SET estado=0 WHERE idMesero=?";
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, mesero.getIdMesero());//seteamos el parametro

            int exe = pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if (exe == 1) {
                JOptionPane.showMessageDialog(null, "Mesero Eliminado");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para Eliminar Mesero" + ex.getMessage());
        }

    }
//----------------------------------------------------------------------------------------------------------------------------------------------    

    public void modificarMesero(Mesero mesero) {//este metodo se encargará de hacer una modificacion en la tabla(UPDATE)
        String sql = "UPDATE mesero SET dni=?,nombre=?,usuario=?,contraseña=? WHERE IdMesero=?";
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            //seteamos los parametros
            pre.setInt(1, mesero.getDni());
            pre.setString(2, mesero.getNombre());
            pre.setString(3, mesero.getUsuario());
            pre.setString(4, mesero.getContraseña());
            pre.setInt(5, mesero.getIdMesero());

            int exe = pre.executeUpdate();//executeUpdate devuelve un entero y lo almacenamos en una variable
            if (exe == 1) {
                JOptionPane.showMessageDialog(null, "Mesero Modificado!");
            }
            pre.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla para Modificar mesero" + ex.getMessage());
        }
    }
//----------------------------------------------------------------------------------------------------------------------------------------------

    public Mesero buscarMesero(int id) {
        String sql = "SELECT nombre, dni , usuario , contraseña FROM mesero WHERE idMesero=? AND estado=1";
        Mesero mesero = null;
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet re = pre.executeQuery();
            if (re.next()) {
                mesero = new Mesero();
                mesero.setIdMesero(id);
                mesero.setNombre(re.getString("nombre"));
                mesero.setDni(re.getInt("dni"));
                mesero.setUsuario(re.getString("usuario"));
                mesero.setContraseña(re.getString("contraseña"));
                mesero.setEstado(true);

            } else {

                JOptionPane.showMessageDialog(null, "No existe el mesero");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesero para buscar mesero" + ex.getMessage());
        }
        return mesero;
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------- 

    public Mesero buscarMeseroPorDni(int dni) {
        String sql = "SELECT idMesero,nombre,dni,usuario,contraseña FROM mesero WHERE dni=? AND estado=1";
        Mesero mesero = null;
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, dni);
            ResultSet re = pre.executeQuery();
            if (re.next()) {
                mesero = new Mesero();

                mesero.setIdMesero(re.getInt("idMesero"));
                mesero.setNombre(re.getString("nombre"));
                mesero.setDni(re.getInt("dni"));
                mesero.setUsuario(re.getString("usuario"));
                mesero.setContraseña(re.getString("contraseña"));
                mesero.setEstado(true);
            } else {
                JOptionPane.showMessageDialog(null, "No Existe ese Mesero");
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder" + ex.getMessage());

        }
        return mesero;
    }
    //----------------------------------------------------------------------------------------------------------------------------------------------

    public List<Mesero> listarMeseros() {
        ArrayList<Mesero> meseross = new ArrayList<>();
        String sql = "SELECT * FROM mesero WHERE estado=1";
        try {
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet re = pre.executeQuery();//devuelve un resultset
            while (re.next()) {
                Mesero meser = new Mesero();
                meser.setIdMesero(re.getInt("idMesero"));
                meser.setNombre(re.getString("nombre"));
                meser.setDni(re.getInt("dni"));
                meser.setUsuario(re.getString("usuario"));
                meser.setContraseña(re.getString("contraseña"));
                meser.setEstado(re.getBoolean("estado"));
                meseross.add(meser);
            }
            pre.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesa");
        }
        return meseross;
    }
    //------------------------------------------------------------------------------------------------------------------------------------------

    public Mesero buscarMeseroPorNombre(String nombreMesero) {
        String sql = "SELECT idMesero, nombre FROM mesero WHERE nombre = ?";
        Mesero mesero = null;

        try {
            // Preparar la consulta SQL
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, nombreMesero);  // Se asume que 'nombreMesero' es el nombre del mesero
            ResultSet re = pre.executeQuery();

            // Si el mesero existe
            if (re.next()) {
                mesero = new Mesero();
                mesero.setIdMesero(re.getInt("idMesero"));
                mesero.setNombre(re.getString("nombre"));
            } else {
                // Si no se encuentra el mesero
                JOptionPane.showMessageDialog(null, "No se encontró un mesero con ese nombre.");
            }

            pre.close();  // Cerrar el PreparedStatement
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Mesero: " + ex.getMessage());
        }

        return mesero;  // Retorna null si no se encuentra el mesero
    }
     //------------------------------------------------------------------------------------------------------------------------------------------
public void darDeAltaMesero(int dni) {
  
    String sql = "UPDATE mesero SET estado = 1 WHERE dni = ?";
    try {
        PreparedStatement pre = con.prepareStatement(sql);
        pre.setInt(1, dni);
        int filasAfectadas = pre.executeUpdate();
        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Mesero dado de alta.");
        } else {
            JOptionPane.showMessageDialog(null, "Error al dar de alta al mesero.");
        }
        pre.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al dar de alta: " + ex.getMessage());
    }

}
//------------------------------------------------------------------------------------------------------------------------------------------
public Mesero buscarMeseroBaja(int dni) {
    String sql = "SELECT idMesero, nombre, dni, usuario, contraseña, estado FROM mesero WHERE dni=?";
    Mesero mesero = null;
    try {
        PreparedStatement pre = con.prepareStatement(sql);
        pre.setInt(1, dni);
        ResultSet re = pre.executeQuery();
        if (re.next()) {
            mesero = new Mesero();
            mesero.setIdMesero(re.getInt("idMesero"));
            mesero.setNombre(re.getString("nombre"));
            mesero.setDni(re.getInt("dni"));
            mesero.setUsuario(re.getString("usuario"));
            mesero.setContraseña(re.getString("contraseña"));
            mesero.setEstado(re.getBoolean("estado")); // Utiliza el valor de estado directamente
        } else {
            JOptionPane.showMessageDialog(null, "No Existe ese Mesero");
        }
        pre.close();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al acceder: " + ex.getMessage());
    }
    return mesero;
}
}
