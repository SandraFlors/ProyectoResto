package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.Pedido;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PedidoData {

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public PedidoData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }

    //Métodos------------------------------------------------------------------------------------------------------------------------------
    public void guardarPedido(Pedido pedido) {//este metodo tendrá la tarea de hacer in INSERT en la tabla peedido
        String sql = "INSERT INTO pedido(estado, idMesa, idMesero) VALUES (?, ?, ?)";
        PreparedStatement pre = null;
        ResultSet re = null;

        try {
            pre = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pre.setBoolean(1, pedido.isEstado());
            pre.setInt(2, pedido.getMesa().getIdMesa());
            pre.setInt(3, pedido.getMesero().getIdMesero());

            int exe = pre.executeUpdate();
            if (exe == 1) {
                re = pre.getGeneratedKeys();
                if (re != null && re.next()) {
                    pedido.setIdPedido(re.getInt(1));
                    JOptionPane.showMessageDialog(null, "Pedido Agregado");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar el pedido.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al acceder a la tabla Pedido: " + ex.getMessage());
        } finally {
            try {
                if (re != null) {
                    re.close();
                }
                if (pre != null) {
                    pre.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar los recursos: " + e.getMessage());
            }
        }
    }
    //Métodos------------------------------------------------------------------------------------------------------------------------------    

    public boolean eliminarPedido(int idPedido) {
        String sql = "DELETE FROM pedidos WHERE idPedido = ?";
        try (PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, idPedido);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //------------------------------------------------------------------------------------------------------------------------------       
}
