package resto.accesoAdatos;

import java.sql.*;//las clases de jdbc estan en el paquete de SQL le ponemos IMPORT JAVA.SQL.* para que importe las clases a medida que las necesite

import javax.swing.JOptionPane;

public class ConexionBD { //CLASE CONEXION va a devolver atraves del metodo getConnection un connection para que las clases data la utilizen
    //y hagan las operaciones necesarias sobre la base de datos

    //*****Para que JDBC se conecte a nuestra base de datos falta el driver de coneccion , (AGREGADO/IMPORTADO "MARIADB" EN LIBRERIA)*****
    //creacion de atributos estaticos para ser accedidos por un metodo estatico 
    //las constantes estan escritos con identificadores"nombres" en MAYUSCULA
    private static final String URL = "jdbc:mariadb://localhost/"; //URL de coneccion a nuestra base de datos(jdbc/mariadb/+/ip=equipo donde se encuentra 
    //el servidor,en nuestro caso es nuestra pc entonces seria LOCALHOST
    private static final String BD = "resto"; //nombre de la base de datos
    private static final String USUARIO = "root";//por defecto el nombre de usuario de la base de datos de mysql es ROOT
    private static final String CONTRASEÑA = "";//la contraseña es una cadena vacia
    private static Connection connection;//variable atributo statica de tipo Connection que utilizaran las clases data 

    public static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public ConexionBD() {
    }//constructor privado = no se pueden instanciar/crear objetos de esta clase

    public static Connection getConexion() { //a travez del metodo statico GETCONEXION podra devolver al exterior un connection 
        //devolvera un objeto de tipo Connection - para poder devolver un connection PRIMERO HAY QUE CARGAR LOS DRIVERS Y ESTABLECER LA CONECION BD

        if (connection == null) {//verifica si es la 1er vez que se hará la invocacion al metodo
            try {
                Class.forName("org.mariadb.jdbc.Driver");//encerramos en un try catch ya que puede lanzar una excepcion 

                connection = DriverManager.getConnection(URL + BD, USUARIO, CONTRASEÑA);//creacion del objeto connection , el cual recibe la url/bd/usuario/contraseña

                JOptionPane.showMessageDialog(null, "Conectado!");
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error al cargar los drivers" + ex.getMessage());//si se llega a producir la excepcion se mostrará el msj
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al intentar conectarse a la BASE DE DATOS" + ex.getMessage());
            }
        }
        return connection;
    }

}
