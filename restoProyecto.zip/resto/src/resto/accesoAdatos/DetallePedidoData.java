package resto.accesoAdatos;

import java.sql.Connection;
import resto.entidades.DetallePedido;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

public class DetallePedidoData {

    private Connection con = null;//atributo Connection (lo utilizarán todas las clases Data para poder guardar/eliminar/consultar datos de la base de datos

    public DetallePedidoData() {//Constructor para inicializar la variable atributo Connection
        con = ConexionBD.getConexion();//se encargara de cargar los driver y establecer la conexion a la base de datos SI ES QUE NO SE HIZO ANTES
    }

    //---------------METODOS-------------------------------------------------------------------------------------------------
    // Método para eliminar un detalle de pedido
    public void eliminarDetallePedido(int idPedido) throws SQLException {
        String sql = "DELETE FROM detallepedido WHERE idPedido = ?";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPedido);  // Establecer el idPedido para la consulta
            pst.executeUpdate();  // Ejecutar la consulta para eliminar los detalles
        } catch (SQLException e) {
            System.out.println("Error al eliminar detalle de pedido: " + e.getMessage());
            throw e;  // Propagar la excepción si ocurre un error
        }
    }

    //---------------METODOS-------------------------------------------------------------------------------------------------
    public List<DetallePedido> obtenerDetallesPorPedido(int idPedido) { //detalles del pedido
        List<DetallePedido> detalles = new ArrayList<>();
        String query = "SELECT * FROM detallePedido WHERE idPedido = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, idPedido);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                DetallePedido detalle = new DetallePedido();
                detalle.setIdDetalle(rs.getInt("idDetalle"));
//                detalle.setIdPedido(rs.getInt("idPedido"));
//                detalle.setIdProducto(rs.getInt("idProducto"));
                detalle.setCantidad(rs.getInt("cantidad"));
                detalle.setTotal(rs.getDouble("total"));

                detalles.add(detalle);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (detalles.isEmpty()) {
            System.out.println("No se encontraron detalles para el pedido " + idPedido);
        }
        return detalles;
    }
    //---------------METODOS-------------------------------------------------------------------------------------------------

    public boolean actualizarDetallePedido(int idDetalle, int cantidad, double total) { //actualizar o modificar
        String query = "UPDATE detallePedido SET cantidad = ?, total = ? WHERE idDetalle = ?";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cantidad);
            stmt.setDouble(2, total);
            stmt.setInt(3, idDetalle);

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0; // Devuelve true si la actualización fue exitosa
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false; // Si ocurre un error
    }

    //METODOS-------------------------------------------------------------------------------------------------
    public boolean agregarDetallePedido(int idPedido, int idProducto, int cantidad, double total) {
        String query = "INSERT INTO detallepedido (idPedido, idProducto, cantidad, total) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, idPedido);
            stmt.setInt(2, idProducto);
            stmt.setInt(3, cantidad);
            stmt.setDouble(4, total);

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0; // Devuelve true si la inserción fue exitosa
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
   
}
