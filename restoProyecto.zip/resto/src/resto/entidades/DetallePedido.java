package resto.entidades;

public class DetallePedido {

    //ATRIBUTOS-----------------------------------------------------------------
    private int idDetalle;
    private Producto producto;
    private Pedido pedido;
    private int cantidad;
    private double total;

    //CONSTRUCTORES-------------------------------------------------------------
    public DetallePedido() {
    }

    public DetallePedido(int idDetalle, Producto producto, Pedido pedido, int cantidad, double total) {
        this.idDetalle = idDetalle;
        this.producto = producto;
        this.pedido = pedido;
        this.cantidad = cantidad;
        this.total = total;
    }

    public DetallePedido(int cantidad, double total) {
        this.cantidad = cantidad;
        this.total = total;
    }

    // Getters y Setters--------------------------------------------------------
    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    //TO STRING-----------------------------------------------------------------

    @Override
    public String toString() {
        return "DetallePedido{" + "idDetalle=" + idDetalle + ", producto=" + producto + ", pedido=" + pedido + ", cantidad=" + cantidad + ", total=" + total + '}';
    }

}
