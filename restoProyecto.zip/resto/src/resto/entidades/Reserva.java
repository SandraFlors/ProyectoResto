package resto.entidades;

import java.time.LocalDate;
import java.time.LocalTime;

public class Reserva {
    //ATRIBUTOS-------------------------------------------------------------------

    private int idReserva;
    private String nombre;
    private long dni;
    private LocalDate fecha;
    private LocalTime hora;
    private boolean estado;
    private Mesa mesa;
    private int idMesa;

    //CONSTRUCTORES---------------------------------------------------------------
    public Reserva() {
    }

    public Reserva(int idReserva, String nombre, long dni, LocalDate fecha, LocalTime hora, boolean estado) {
        this.idReserva = idReserva;
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public Reserva(String nombre, long dni, LocalDate fecha, LocalTime hora, boolean estado) {
        this.nombre = nombre;
        this.dni = dni;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }
    
    //GETTERS Y SETTERS---------------------------------------------------------
    public int getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(int idMesa) {
        this.idMesa = idMesa;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    //TO STRING-----------------------------------------------------------------
    @Override
    public String toString() {
        return " nombre" + nombre + " dni=" + dni + " fecha=" + fecha + " hora=" + hora + " estado" + estado ;
    }

}
