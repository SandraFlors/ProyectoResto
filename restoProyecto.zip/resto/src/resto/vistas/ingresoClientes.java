
package resto.vistas;

import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;
import resto.accesoAdatos.DetallePedidoData;
import resto.accesoAdatos.MesaData;
import resto.accesoAdatos.MeseroData;
import resto.accesoAdatos.PedidoData;
import resto.accesoAdatos.ProductoData;
import resto.entidades.DetallePedido;
import resto.entidades.Mesa;
import resto.entidades.Mesero;
import resto.entidades.Pedido;
import resto.entidades.Producto;
import java.sql.SQLException;

public class ingresoClientes extends javax.swing.JInternalFrame {

    private ArrayList<Mesa> listaM;
    private ArrayList<Mesero> listameser;
    private ArrayList<Producto> listaProductos = new ArrayList<>();
    private ArrayList<Pedido> listaPedido = new ArrayList<>();

    private MesaData mesaData;
    private MeseroData meserData;
    private ProductoData proData;
    private PedidoData pedData;
    private DetallePedidoData detallePedidoData;

    private Pedido pedidoActual = null;
    private Producto productoActual = null;
    private Mesa mesaActaul = null;
    private Mesero meseroActual = null;
    private DetallePedido detalleActual = null;

    private DefaultTableModel modelo;

    public ingresoClientes() {
        initComponents();

        proData = new ProductoData();
        listaProductos = (ArrayList<Producto>) proData.listarProducto();
        mesaData = new MesaData();
        listaM = (ArrayList<Mesa>) mesaData.listarMesas();
        meserData = new MeseroData();
        listameser = (ArrayList<Mesero>) meserData.listarMeseros();
        pedData = new PedidoData();
        detallePedidoData = new DetallePedidoData();

        modelo = new DefaultTableModel();

        //metodos
        armarCabezeraTabla();
        cargarMesas();
        cargarMeseros();
        cargarTablaProductos();

        JTextArea textAreaDetalle = new JTextArea(10, 30); // 10 filas, 30 columnas
        textAreaDetalle.setEditable(false); // Hacer que sea solo lectura
        JScrollPane scrollPane = new JScrollPane(textAreaDetalle);
        jPanel1.add(scrollPane); // Agregar al panel de la interfaz

        confirmarPedido();
        cancelarPedido();
    }

    private void cargarMesas() {
        comboMesa.removeAllItems();  // Limpiamos el ComboBox para evitar duplicados
        for (Mesa mesa : listaM) {
            comboMesa.addItem(mesa);  // Añadimos las mesas al ComboBox
        }
    }
    //---------------------------------------------------------------------------

    private void cargarMeseros() {
        comboMesero.removeAllItems();  // Limpiamos el ComboBox para evitar duplicados
        for (Mesero item : listameser) {
            comboMesero.addItem(item);  // Añadimos cada mesero al ComboBox
        }
    }
    //--------------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        ImageIcon icono=new ImageIcon(getClass().getResource("/resto/icons/humo.jpg"));
        Image miImagen=icono.getImage();
        jPanel1 = new javax.swing.JPanel(){
            public void paintComponent(Graphics g){
                g.drawImage(miImagen,0,0,getWidth(),getHeight(),this);
            }
        };
        btnSalir = new javax.swing.JButton();
        lblselecMesa = new javax.swing.JLabel();
        lblselecMesero = new javax.swing.JLabel();
        lblselecProducto = new javax.swing.JLabel();
        btnAgregarPedido = new javax.swing.JButton();
        comboMesa = new javax.swing.JComboBox<>();
        comboMesero = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        lblPedidos = new javax.swing.JLabel();
        btnAgregarPedido1 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        textAreaDetalle = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        jButton1.setText("jButton1");

        jButton2.setText("jButton2");

        setTitle("Pedido");

        btnSalir.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirMouseClicked(evt);
            }
        });
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        lblselecMesa.setBackground(new java.awt.Color(0, 0, 0));
        lblselecMesa.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblselecMesa.setForeground(new java.awt.Color(255, 255, 255));
        lblselecMesa.setText("Seleccione Mesa : ");

        lblselecMesero.setBackground(new java.awt.Color(0, 0, 0));
        lblselecMesero.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblselecMesero.setForeground(new java.awt.Color(255, 255, 255));
        lblselecMesero.setText("Seleccione Mesero : ");

        lblselecProducto.setBackground(new java.awt.Color(0, 0, 0));
        lblselecProducto.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblselecProducto.setForeground(new java.awt.Color(255, 255, 255));
        lblselecProducto.setText("Seleccione Poducto :");

        btnAgregarPedido.setBackground(new java.awt.Color(255, 255, 255));
        btnAgregarPedido.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnAgregarPedido.setForeground(new java.awt.Color(0, 0, 0));
        btnAgregarPedido.setText("AgregarPedido");
        btnAgregarPedido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarPedidoMouseClicked(evt);
            }
        });
        btnAgregarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarPedidoActionPerformed(evt);
            }
        });

        comboMesa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboMesaMouseClicked(evt);
            }
        });
        comboMesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMesaActionPerformed(evt);
            }
        });

        comboMesero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboMeseroMouseClicked(evt);
            }
        });
        comboMesero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMeseroActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabla);

        lblPedidos.setBackground(new java.awt.Color(0, 0, 0));
        lblPedidos.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        lblPedidos.setForeground(new java.awt.Color(255, 255, 255));
        lblPedidos.setText("Pedidos");

        btnAgregarPedido1.setBackground(new java.awt.Color(255, 255, 255));
        btnAgregarPedido1.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnAgregarPedido1.setForeground(new java.awt.Color(0, 0, 0));
        btnAgregarPedido1.setText("Nuevo");
        btnAgregarPedido1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarPedido1MouseClicked(evt);
            }
        });
        btnAgregarPedido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarPedido1ActionPerformed(evt);
            }
        });

        textAreaDetalle.setColumns(20);
        textAreaDetalle.setRows(5);
        jScrollPane4.setViewportView(textAreaDetalle);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 0));
        jButton3.setText("Confirmar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 0, 0));
        jButton4.setText("Cancelar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblselecProducto)
                            .addComponent(lblselecMesero)
                            .addComponent(lblselecMesa))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboMesa, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboMesero, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 179, Short.MAX_VALUE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane4)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(btnAgregarPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53)
                                .addComponent(btnAgregarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(39, 39, 39))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblPedidos, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboMesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecMesa))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboMesero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecMesero))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblselecProducto))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregarPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4)))
                .addGap(122, 122, 122))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 567, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseClicked
        //BOTON SALIR
        dispose();
    }//GEN-LAST:event_btnSalirMouseClicked

    private void comboMesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboMesaActionPerformed

    private void comboMeseroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMeseroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboMeseroActionPerformed
    //--------------------------------------------------------------------------

    private void btnAgregarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarPedidoActionPerformed
        // BOTON AGREGAR PEDIDO
        Mesa mesaSeleccionada = (Mesa) comboMesa.getSelectedItem();
        if (mesaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una mesa.");
            return;
        }

        // 2. Validación del mesero seleccionado
        Mesero meseroSeleccionado = (Mesero) comboMesero.getSelectedItem();
        if (meseroSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un mesero.");
            return;
        }

        // Obtener el nombre del mesero
        String nombreMesero = meseroSeleccionado.getNombre();

        // 3. Validación de la selección de un producto
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto.");
            return;
        }

        // Obtener detalles del producto
        String productoSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 0);
        double precio = (Double) tabla.getValueAt(filaSeleccionada, 1);
        int idProducto = (Integer) tabla.getValueAt(filaSeleccionada, 2);
      

        // Crear el objeto Pedido
        Pedido nuevoPedido = new Pedido(true, mesaSeleccionada, meseroSeleccionado);
        pedData.guardarPedido(nuevoPedido);

        // Insertar los detalles del pedido
        int cantidad=1;
        double total = precio * cantidad; // Calcular el total
        detallePedidoData.agregarDetallePedido(nuevoPedido.getIdPedido(), idProducto, cantidad, total);

        // Obtener los detalles del pedido para mostrar
        List<DetallePedido> detalles = detallePedidoData.obtenerDetallesPorPedido(nuevoPedido.getIdPedido());
        StringBuilder detallePedidoStr = new StringBuilder("Detalles del Pedido:\n");
        double montoTotal = 0.0;

        for (DetallePedido detalle : detalles) {
            detallePedidoStr.append("Producto: ").append(detalle.getProducto())
                    .append(", Cantidad: ").append(detalle.getCantidad())
                    .append(", Total: $").append(detalle.getTotal())
                    .append("\n");
            montoTotal += detalle.getTotal();
        }

        detallePedidoStr.append("\nMonto Total: $").append(montoTotal);

        // Actualizar el JTextArea
        textAreaDetalle.setText(detallePedidoStr.toString());
    }//GEN-LAST:event_btnAgregarPedidoActionPerformed

    //---------------------------------------------------------------------------

    private void btnAgregarPedido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarPedido1ActionPerformed
        // BOTON NUEVO
        limpiarCampos();
        productoActual = null;
        mesaActaul = null;
        meseroActual = null;

        cargarTablaProductos();
    }//GEN-LAST:event_btnAgregarPedido1ActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        //BOTON SALIR
        dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void comboMesaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboMesaMouseClicked
        // 
//       
//       for(Mesa item: listaM){
//          comboMesa.addItem(item);
//       
//    }
    }//GEN-LAST:event_comboMesaMouseClicked

    private void comboMeseroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboMeseroMouseClicked
// for(Mesero item: listameser){
//          comboMesero.addItem(item);
//       }       
    }//GEN-LAST:event_comboMeseroMouseClicked

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        // 
    }//GEN-LAST:event_tablaMouseClicked

    private void btnAgregarPedidoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarPedidoMouseClicked

    }//GEN-LAST:event_btnAgregarPedidoMouseClicked

    private void btnAgregarPedido1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarPedido1MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_btnAgregarPedido1MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // BOTON CONFIRMAR
        confirmarPedido();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // BOTON CANCELAR
        cancelarPedido();
    }//GEN-LAST:event_jButton4ActionPerformed

//------------------------------------------------------------------------------------
    public void limpiarCampos() {
        comboMesa.setSelectedItem(null);
        comboMesero.setSelectedItem(null);
        textAreaDetalle.setText(" ");

    }
    //-----------------------------------------------------------------------------------

    public void limpiarTabla(JTable tabla) {
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        model.setRowCount(0);  // Elimina todas las filas
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarPedido;
    private javax.swing.JButton btnAgregarPedido1;
    private javax.swing.JButton btnSalir;
    private javax.swing.JComboBox<Mesa> comboMesa;
    private javax.swing.JComboBox<Mesero> comboMesero;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel lblPedidos;
    private javax.swing.JLabel lblselecMesa;
    private javax.swing.JLabel lblselecMesero;
    private javax.swing.JLabel lblselecProducto;
    private javax.swing.JTable tabla;
    private javax.swing.JTextArea textAreaDetalle;
    // End of variables declaration//GEN-END:variables

    //---------------------------------------------------------------------------
    //---------------------------------------------------------------------------
    private void armarCabezeraTabla() {
        ArrayList<String> filaCabecera = new ArrayList<>();
        filaCabecera.add("Producto");
        filaCabecera.add("Precio");
     
        for (String it : filaCabecera) {
            modelo.addColumn(it);
        }
        tabla.setModel(modelo);
    }
    //---------------------------------------------------------------------------

    public void cargarTablaProductos() {
        // Verifica que tienes productos en la lista
        if (listaProductos != null && !listaProductos.isEmpty()) {
            // Crear el modelo de la tabla
            DefaultTableModel modelo = new DefaultTableModel();

            // Definir las columnas
            modelo.addColumn("Nombre");
            modelo.addColumn("Precio");
            modelo.addColumn("Stock");
         

            // Llenar la tabla con los productos
            for (Producto producto : listaProductos) {
                modelo.addRow(new Object[]{
                    producto.getNombre(),
                    producto.getPrecio(),
                    producto.getIdProducto(),
                    
                });
            }

            // Asignar el modelo a la tabla
            tabla.setModel(modelo);
        } else {
            System.out.println("No hay productos para mostrar.");
        }
    }
    //----------------------------------------------------------------------------------------

    public void guardarPedido(Pedido pedido) {
        listaPedido.add(pedido); // Si estás usando una lista para almacenar los pedidos
        // O, si es en la base de datos, hacer la inserción correspondiente
        System.out.println("Pedido guardado: " + pedido);
    }

    private void confirmarPedido() {
        // Aquí puedes realizar la lógica para confirmar el pedido,
        // como insertar en la base de datos o actualizar el estado del pedido

        // Si es necesario, puedes limpiar el TextArea o realizar otra acción
        textAreaDetalle.setText("Pedido Confirmado");

    }
    //----------------------------------------------------------------------------------------
    // Método para cancelar el pedido

    private void cancelarPedido() {
        try {
            // Obtener el idPedido que deseas cancelar
            int idPedido = 34;  // Este ID debe ser dinámico según el pedido que estás cancelando

            // Llamar al método para eliminar el detalle del pedido de la base de datos
            detallePedidoData.eliminarDetallePedido(idPedido);

            // Limpiar el TextArea o realizar otras acciones en la interfaz
            textAreaDetalle.setText("Pedido Cancelado");

        } catch (SQLException e) {
            // Si ocurre un error, mostrar un mensaje de error
            JOptionPane.showMessageDialog(this, "Error al cancelar el pedido: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    //----------------------------------------------------------------------------------------
}
    
    
    
    
    

