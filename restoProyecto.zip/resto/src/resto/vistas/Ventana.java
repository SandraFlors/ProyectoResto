  
package resto.vistas;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class Ventana extends javax.swing.JFrame {

    public Ventana() {
        initComponents();
        this.setVisible(true);
       
        this.setLocationRelativeTo(null);
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jMenuItem6 = new javax.swing.JMenuItem();
        ImageIcon icono=new ImageIcon(getClass().getResource("/resto/icons/fuegoazul.jpg"));

        Image miImagen=icono.getImage();
        Escritorio = new javax.swing.JDesktopPane(){
            public void paintComponent(Graphics g){
                g.drawImage(miImagen,0,0,getWidth(),getHeight(),this);
            }
        };
        lbltelefono = new javax.swing.JLabel();
        lblhubicacion = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        lblSubtitulo = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuMeseros = new javax.swing.JMenu();
        itemMeseros = new javax.swing.JMenuItem();
        menuMesa = new javax.swing.JMenu();
        itemClientes = new javax.swing.JMenuItem();
        menuReserva = new javax.swing.JMenu();
        itemFormReservas = new javax.swing.JMenuItem();
        itemVerReservas = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenu();

        jButton1.setText("jButton1");

        jMenuItem6.setText("jMenuItem6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Resto Delicatessen");
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Escritorio.setToolTipText("");
        Escritorio.setPreferredSize(new java.awt.Dimension(500, 550));

        lbltelefono.setBackground(new java.awt.Color(0, 0, 0));
        lbltelefono.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        lbltelefono.setForeground(new java.awt.Color(255, 255, 255));
        lbltelefono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resto/icons/call.png"))); // NOI18N
        lbltelefono.setText("2664703074");

        lblhubicacion.setBackground(new java.awt.Color(0, 0, 0));
        lblhubicacion.setFont(new java.awt.Font("Dialog", 3, 18)); // NOI18N
        lblhubicacion.setForeground(new java.awt.Color(255, 255, 255));
        lblhubicacion.setText("San Luis Capital");

        lblTitulo.setBackground(new java.awt.Color(0, 0, 0));
        lblTitulo.setFont(new java.awt.Font("Book Antiqua", 1, 50)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setText("Delicatessen");

        lblSubtitulo.setBackground(new java.awt.Color(0, 0, 0));
        lblSubtitulo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lblSubtitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblSubtitulo.setText("Restobar");

        Escritorio.setLayer(lbltelefono, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(lblhubicacion, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(lblTitulo, javax.swing.JLayeredPane.DEFAULT_LAYER);
        Escritorio.setLayer(lblSubtitulo, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout EscritorioLayout = new javax.swing.GroupLayout(Escritorio);
        Escritorio.setLayout(EscritorioLayout);
        EscritorioLayout.setHorizontalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                .addGap(514, 541, Short.MAX_VALUE)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                        .addComponent(lbltelefono)
                        .addGap(115, 115, 115))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                        .addComponent(lblhubicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41))))
            .addGroup(EscritorioLayout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addGroup(EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSubtitulo)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        EscritorioLayout.setVerticalGroup(
            EscritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EscritorioLayout.createSequentialGroup()
                .addContainerGap(207, Short.MAX_VALUE)
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSubtitulo)
                .addGap(88, 88, 88)
                .addComponent(lbltelefono)
                .addGap(18, 18, 18)
                .addComponent(lblhubicacion)
                .addGap(223, 223, 223))
        );

        getContentPane().add(Escritorio, new org.netbeans.lib.awtextra.AbsoluteConstraints(4, 4, 800, 740));

        menuMeseros.setBackground(new java.awt.Color(255, 255, 255));
        menuMeseros.setForeground(new java.awt.Color(0, 0, 0));
        menuMeseros.setText("Meseros");
        menuMeseros.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        itemMeseros.setBackground(new java.awt.Color(255, 255, 255));
        itemMeseros.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemMeseros.setForeground(new java.awt.Color(0, 0, 0));
        itemMeseros.setText("Formulario Meseros");
        itemMeseros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemMeserosActionPerformed(evt);
            }
        });
        menuMeseros.add(itemMeseros);

        jMenuBar1.add(menuMeseros);

        menuMesa.setBackground(new java.awt.Color(255, 255, 255));
        menuMesa.setForeground(new java.awt.Color(0, 0, 0));
        menuMesa.setText("Producto y Pedidos");
        menuMesa.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        itemClientes.setBackground(new java.awt.Color(255, 255, 255));
        itemClientes.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemClientes.setForeground(new java.awt.Color(0, 0, 0));
        itemClientes.setText("Formulario Producto");
        itemClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemClientesActionPerformed(evt);
            }
        });
        menuMesa.add(itemClientes);

        jMenuBar1.add(menuMesa);

        menuReserva.setBackground(new java.awt.Color(255, 255, 255));
        menuReserva.setForeground(new java.awt.Color(0, 0, 0));
        menuReserva.setText("Reservas");
        menuReserva.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N

        itemFormReservas.setBackground(new java.awt.Color(255, 255, 255));
        itemFormReservas.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemFormReservas.setForeground(new java.awt.Color(0, 0, 0));
        itemFormReservas.setText("FormularioReservas");
        itemFormReservas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemFormReservasActionPerformed(evt);
            }
        });
        menuReserva.add(itemFormReservas);

        itemVerReservas.setBackground(new java.awt.Color(255, 255, 255));
        itemVerReservas.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        itemVerReservas.setForeground(new java.awt.Color(0, 0, 0));
        itemVerReservas.setText("Ver Reservas");
        itemVerReservas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemVerReservasActionPerformed(evt);
            }
        });
        menuReserva.add(itemVerReservas);

        jMenuBar1.add(menuReserva);

        menuSalir.setBackground(new java.awt.Color(255, 255, 255));
        menuSalir.setForeground(new java.awt.Color(0, 0, 0));
        menuSalir.setText("Salir");
        menuSalir.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        menuSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuSalirMouseClicked(evt);
            }
        });
        menuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSalirActionPerformed(evt);
            }
        });
        jMenuBar1.add(menuSalir);

        setJMenuBar(jMenuBar1);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void itemMeserosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemMeserosActionPerformed
     
        IngresoMeseros mesero = new IngresoMeseros();

        Escritorio.add(mesero);
        mesero.setVisible(true);
         this.setLocationRelativeTo(null);
   
    }//GEN-LAST:event_itemMeserosActionPerformed

    private void itemClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemClientesActionPerformed

        ingresoClientes cliente = new ingresoClientes();

        Escritorio.add(cliente);
        cliente.setVisible(true);
    }//GEN-LAST:event_itemClientesActionPerformed

    private void menuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSalirActionPerformed
  
    }//GEN-LAST:event_menuSalirActionPerformed

    private void menuSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuSalirMouseClicked
  
        System.exit(0);
    }//GEN-LAST:event_menuSalirMouseClicked

    
    private void itemFormReservasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemFormReservasActionPerformed
        
        FormulariosReservas formula = new FormulariosReservas();

        Escritorio.add(formula);
        formula.setVisible(true);
    }//GEN-LAST:event_itemFormReservasActionPerformed

    private void itemVerReservasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemVerReservasActionPerformed
        
        ListarReservas lista = new ListarReservas();
        Escritorio.add(lista);
        lista.setVisible(true);
    }//GEN-LAST:event_itemVerReservasActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    private void centrarInternalFrame(IngresoMeseros mesero) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public class MainClass {

        public static void main(String[] args) {
            // Configuración de la interfaz gráfica
            javax.swing.SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    // Crear y mostrar el JFrame
                    new Ventana().setVisible(true);

                }
            });
        }
    }

//----------------------------------------------------------------------------- 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane Escritorio;
    private javax.swing.JMenuItem itemClientes;
    private javax.swing.JMenuItem itemFormReservas;
    private javax.swing.JMenuItem itemMeseros;
    private javax.swing.JMenuItem itemVerReservas;
    private javax.swing.JButton jButton1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JLabel lblSubtitulo;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblhubicacion;
    private javax.swing.JLabel lbltelefono;
    private javax.swing.JMenu menuMesa;
    private javax.swing.JMenu menuMeseros;
    private javax.swing.JMenu menuReserva;
    private javax.swing.JMenu menuSalir;
    // End of variables declaration//GEN-END:variables
}
