package resto.vistas;

import java.awt.Graphics;
import java.awt.Image;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import resto.accesoAdatos.MesaData;
import resto.accesoAdatos.ReservaData;
import resto.entidades.Mesa;
import resto.entidades.Reserva;

public class FormulariosReservas extends javax.swing.JInternalFrame {

    private ArrayList<Mesa> listaM;
    private MesaData mesaData;
    private Mesa mesaActaul = null;
    private Reserva reservaActual = null;
    private ReservaData reData;
    private DefaultTableModel modelo;

    public FormulariosReservas() {
        initComponents();
        mesaData = new MesaData();
        reData = new ReservaData();
        listaM = (ArrayList<Mesa>) mesaData.listarMesas();
        limpiarCampos();
        inicializarComboHora();
        inicializarComboMinuto();
        borrarFila();
        modelo = new DefaultTableModel();
        armarTabla();
        tablaMesa.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        tablaMesa.setModel(modelo);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField5 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        ImageIcon icono=new ImageIcon(getClass().getResource("/resto/icons/humo.jpg"));
        Image miImagen=icono.getImage();
        jPanel1 = new javax.swing.JPanel(){
            public void paintComponent(Graphics g){
                g.drawImage(miImagen,0,0,getWidth(),getHeight(),this);
            }
        };
        btnSalir = new javax.swing.JButton();
        btnSalir1 = new javax.swing.JButton();
        btnSalir2 = new javax.swing.JButton();
        btnSalir3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtdni = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        DATAchoser = new com.toedter.calendar.JDateChooser();
        comboHora = new javax.swing.JComboBox<>();
        comboMinuto = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaMesa = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        jTextField5.setText("jTextField5");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setTitle("Reservas");

        btnSalir.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir.setText("Salir");
        btnSalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalirMouseClicked(evt);
            }
        });
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        btnSalir1.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir1.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir1.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir1.setText("Eliminar");
        btnSalir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalir1MouseClicked(evt);
            }
        });
        btnSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalir1ActionPerformed(evt);
            }
        });

        btnSalir2.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir2.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir2.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir2.setText("Guardar");
        btnSalir2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalir2MouseClicked(evt);
            }
        });
        btnSalir2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalir2ActionPerformed(evt);
            }
        });

        btnSalir3.setBackground(new java.awt.Color(255, 255, 255));
        btnSalir3.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnSalir3.setForeground(new java.awt.Color(0, 0, 0));
        btnSalir3.setText("Modificar");
        btnSalir3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalir3MouseClicked(evt);
            }
        });
        btnSalir3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalir3ActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Reservas");

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Seleccione una Mesa :");

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ingrese su Nombre : ");

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Ingrese su DNI : ");

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Seleccione una Fecha : ");

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Seleccion Horario : ");

        btnBuscar.setBackground(new java.awt.Color(255, 255, 255));
        btnBuscar.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 0, 0));
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tablaMesa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tablaMesa);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Book Antiqua", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Limpar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel2))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(comboHora, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(comboMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtNombre)
                            .addComponent(DATAchoser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtdni, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap(56, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnSalir1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSalir3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSalir2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel1)
                .addGap(76, 76, 76)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(jLabel4))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(DATAchoser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(comboHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(comboMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSalir3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(72, 72, 72))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalirMouseClicked
        // BOTON SALIR
        dispose();
    }//GEN-LAST:event_btnSalirMouseClicked

    private void btnSalir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalir1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalir1MouseClicked

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnSalir2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalir2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalir2MouseClicked

    private void btnSalir2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalir2ActionPerformed
        // BOTON GUARDAR
        try {
            // Validación del DNI
            String dniText = txtdni.getText();
            if (dniText.length() != 8) { // Supón que el DNI debe tener 8 dígitos
                JOptionPane.showMessageDialog(this, "El DNI debe tener 8 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            long dni = Long.parseLong(dniText);

            // Obtener el nombre
            String nombre = txtNombre.getText();

            // Buscar reserva por DNI
            reservaActual = reData.buscarReservaPorDni(dni);

            if (reservaActual != null) {  // Si se encuentra una reserva
                // Mostrar la información de la reserva actual
                txtNombre.setText(reservaActual.getNombre());

                // Extraer fecha de la reserva
                LocalDate lc = reservaActual.getFecha();
                java.util.Date date = java.util.Date.from(lc.atStartOfDay(ZoneId.systemDefault()).toInstant());
                DATAchoser.setDate(date);

                // Extraer hora y minuto seleccionados
                String horaSeleccionada = (String) comboHora.getSelectedItem();
                String minutoSeleccionado = (String) comboMinuto.getSelectedItem();

                if (horaSeleccionada == null || minutoSeleccionado == null) {
                    JOptionPane.showMessageDialog(this, "Debe seleccionar una hora y un minuto válidos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int hora = Integer.parseInt(horaSeleccionada);
                int minuto = Integer.parseInt(minutoSeleccionado);
                LocalTime tiempo = LocalTime.of(hora, minuto);

                // Validación de fecha
                java.util.Date selectedDate = DATAchoser.getDate();
                if (selectedDate == null) {
                    JOptionPane.showMessageDialog(this, "Debe seleccionar una fecha", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                lc = selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                // Validación de mesas seleccionadas
                int[] filasSelec = tablaMesa.getSelectedRows();
                if (filasSelec.length == 0) { // Verifica si no se seleccionaron mesas
                    JOptionPane.showMessageDialog(this, "Debe seleccionar al menos una mesa", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Guardar la reserva para cada mesa seleccionada
                for (int fila : filasSelec) {
                    int idMesa = (int) tablaMesa.getValueAt(fila, 1); // Obtener el ID de la mesa
                    Mesa mesa = mesaData.buscarMesa(idMesa); // Buscar mesa por el ID
                    if (mesa != null) {
                        // Crear nueva reserva para esta mesa
                        Reserva nuevaReserva = new Reserva(idMesa, nombre, dni, lc, tiempo, true);

                        // Llamar al método que agrega la reserva (Asegúrate de que este método maneje correctamente la base de datos o el sistema de almacenamiento)
                        reData.agregarReserva(nuevaReserva, idMesa);  // Asumiendo que este método guarda la reserva correctamente

                        JOptionPane.showMessageDialog(this, "Reserva realizada con éxito para la mesa " + idMesa, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Mesa no encontrada para el ID " + idMesa, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                // Si no se encuentra la reserva, entonces crear una nueva reserva
                JOptionPane.showMessageDialog(this, "No existe una reserva previa para este DNI, creando una nueva reserva.", "Información", JOptionPane.INFORMATION_MESSAGE);

                // Validación de mesas seleccionadas
                int[] filasSelec = tablaMesa.getSelectedRows();
                if (filasSelec.length == 0) {
                    JOptionPane.showMessageDialog(this, "Debe seleccionar al menos una mesa", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Guardar la nueva reserva para cada mesa seleccionada
                for (int fila : filasSelec) {
                    int idMesa = (int) tablaMesa.getValueAt(fila, 1);
                    Mesa mesa = mesaData.buscarMesa(idMesa);
                    if (mesa != null) {
                        // Crear nueva reserva para esta mesa
                        Reserva nuevaReserva = new Reserva(idMesa, nombre, dni, LocalDate.now(), LocalTime.now(), true);
                        reData.agregarReserva(nuevaReserva, idMesa);

                        JOptionPane.showMessageDialog(this, "Nueva reserva realizada con éxit " , "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "Mesa no encontrada para el ID " + idMesa, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un número de DNI válido", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error inesperado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSalir2ActionPerformed

    private void btnSalir3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalir3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSalir3MouseClicked
//------------------------------------------------------------------------------------
    private void btnSalir3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalir3ActionPerformed
//BOTON MODIFICAR
        try {
            // Validación del DNI
            String dniText = txtdni.getText();
            if (dniText.length() != 8) { // Supón que el DNI debe tener 8 dígitos
                JOptionPane.showMessageDialog(this, "El DNI debe tener 8 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Integer dni = Integer.parseInt(dniText);

            // Obtener los datos del nombre, fecha, hora, etc.
            String nombre = txtNombre.getText();

            // Obtener la fecha seleccionada en el JDateChooser
            java.util.Date selectedDate = DATAchoser.getDate();
            if (selectedDate == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar una fecha válida", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            LocalDate fecha = selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            // Obtener la hora y el minuto seleccionados
            String horaSeleccionada = (String) comboHora.getSelectedItem();
            String minutoSeleccionado = (String) comboMinuto.getSelectedItem();

            if (horaSeleccionada == null || minutoSeleccionado == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar una hora y un minuto válidos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int hora = Integer.parseInt(horaSeleccionada);
            int minuto = Integer.parseInt(minutoSeleccionado);
            LocalTime horaReserva = LocalTime.of(hora, minuto);

            // Asumimos que el ID de la reserva ya está disponible (puedes obtenerlo de los campos de la interfaz o del objeto existente)
            int idReserva = reservaActual.getIdReserva(); // Este es el ID de la reserva que queremos modificar

            // Crear una nueva reserva con los datos modificados
            Reserva nuevaReserva = new Reserva(idReserva, nombre, dni, fecha, horaReserva, true);

            // Llamar al método que modifica la reserva
            reData.modificarReserva(nuevaReserva); // Llamar a la función que actualiza la base de datos
            JOptionPane.showMessageDialog(this, "Reserva modificada con éxito", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un número de DNI válido", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error inesperado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSalir3ActionPerformed
//---------------------------------------------------------------------------------------
    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // BOTON BUSCAR
        try {
            // Validación del DNI (asegurarse de que sea un número de 8 dígitos)
            String dniText = txtdni.getText();
            if (dniText.length() != 8) { // Verifica si el DNI tiene 8 dígitos
                JOptionPane.showMessageDialog(this, "El DNI debe tener 8 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Integer dni = Integer.parseInt(dniText); // Convierte el texto del DNI a un número entero

            // Buscar reserva por DNI en la base de datos
            reservaActual = reData.buscarReservaPorDni(dni);

            if (reservaActual != null) {
                // Si se encuentra la reserva, mostramos los detalles en los campos correspondientes

                // Establecer nombre
                txtNombre.setText(reservaActual.getNombre());

                // Establecer la fecha (como ejemplo: usando un JDateChooser)
                LocalDate fecha = reservaActual.getFecha();
                java.util.Date date = java.util.Date.from(fecha.atStartOfDay(ZoneId.systemDefault()).toInstant());
                DATAchoser.setDate(date);

                // Establecer hora (suponiendo que la hora está almacenada como LocalTime)
                LocalTime hora = reservaActual.getHora(); // Debes haber guardado la hora en la reserva
                comboHora.setSelectedItem(String.format("%02d", hora.getHour()));  // Setear hora en el combo
                comboMinuto.setSelectedItem(String.format("%02d", hora.getMinute())); // Setear minuto en el combo

                // Mostrar mensaje indicando que la reserva fue encontrada
                JOptionPane.showMessageDialog(this, "Reserva encontrada!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Si no se encuentra la reserva
                JOptionPane.showMessageDialog(this, "No se encontró ninguna reserva con el DNI proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            // Manejo de error si el DNI no es un número válido
            JOptionPane.showMessageDialog(this, "Debe ingresar un número de DNI válido", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            // Manejo de errores generales
            JOptionPane.showMessageDialog(this, "Ocurrió un error inesperado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //BOTON LIMPIAR
        limpiarCampos();
        borrarFila();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalir1ActionPerformed
        // BOTON ELIMINAR 
        try {
            // Validación del DNI
            String dniText = txtdni.getText();
            if (dniText.length() != 8) { // Supón que el DNI debe tener 8 dígitos
                JOptionPane.showMessageDialog(this, "El DNI debe tener 8 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Integer dni = Integer.parseInt(dniText);

            // Buscar la reserva por DNI
            reservaActual = reData.buscarReservaPorDni(dni);

            if (reservaActual == null) {
                JOptionPane.showMessageDialog(this, "No se encontró una reserva con ese DNI", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Confirmar si el usuario realmente quiere eliminar la reserva
            int respuesta = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar la reserva?", "Eliminar Reserva", JOptionPane.YES_NO_OPTION);

            if (respuesta == JOptionPane.YES_OPTION) {
                // Eliminar la reserva
                reData.eliminarReserva(reservaActual);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un número de DNI válido", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error inesperado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSalir1ActionPerformed
    //-----------------------------------------------------------------------------

    public void limpiarCampos() {
        txtNombre.setText("");
        txtdni.setText("");
        DATAchoser.setDate(null);
        comboHora.setSelectedItem(null);
        comboMinuto.setSelectedItem(null);

        if (modelo != null) {
            modelo.setRowCount(0);  // Limpia las filas
            listaM = (ArrayList<Mesa>) mesaData.listarMesas(); // Método ficticio para obtener las mesas

            // Agrega las filas nuevamente
            for (Mesa mesa : listaM) {
                // Asegúrate de agregar cada fila en el formato correcto
                Object[] fila = {mesa.getIdMesa(), mesa.getNumero(), mesa.getCapacidad()};
                modelo.addRow(fila);
            }
        }

    }
//-----------------------------------------------------------------------------

    private void inicializarComboHora() { ///cargar comboHora
        comboHora.removeAllItems();
        for (int i = 0; i < 24; i++) {
            String hora = String.format("%02d", i); // Formatea el número para que tenga dos dígitos
            comboHora.addItem(hora);
        }
    }
    //-----------------------------------------------------------------------------     

    private void inicializarComboMinuto() {
        comboMinuto.removeAllItems();
        for (int i = 0; i < 60; i++) {
            String minuto = String.format("%02d", i); // Formatea el número para que tenga dos dígitos
            comboMinuto.addItem(minuto);
        }
    }
    //-------------------------------------------------------------------------

    private void borrarFila() {
        int indice = tablaMesa.getRowCount() - 1;

        for (int i = indice; i >= 0; i--) {
            tablaMesa.removeAll();
        }
    }
    //-------------------------------------------------------------------------     

    private void armarTabla() {

        ArrayList<Object> cabecera = new ArrayList<>();
        cabecera.add("Numero Mesa");
        cabecera.add("Capacidad");

        for (Object object : cabecera) {
            modelo.addColumn(object);
        }
        tablaMesa.setModel(modelo);
        MesaData mesaData = new MesaData();  // Suponiendo que ya tienes una instancia de MesaData
        List<Mesa> mesasDisponibles = mesaData.listarMesas();  // Lista de mesas disponibles

        // Agregar las filas al modelo con los datos de las mesas
        for (Mesa mesa : mesasDisponibles) {
            Object[] fila = new Object[]{
                mesa.getIdMesa(),
                mesa.getNumero(),
                mesa.getCapacidad()
            };
            modelo.addRow(fila);
        }

        // Establecer el modelo a la JTable
        tablaMesa.setModel(modelo);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser DATAchoser;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnSalir1;
    private javax.swing.JButton btnSalir2;
    private javax.swing.JButton btnSalir3;
    private javax.swing.JComboBox<String> comboHora;
    private javax.swing.JComboBox<String> comboMinuto;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTable tablaMesa;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtdni;
    // End of variables declaration//GEN-END:variables
}
